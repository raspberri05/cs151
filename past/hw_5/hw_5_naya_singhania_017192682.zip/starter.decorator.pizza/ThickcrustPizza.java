public class ThickcrustPizza extends Pizza {
  
	@Override
	public String toString () {
		return "Thick crust pizza, with tomato sauce";
	}
  
	@Override
	public double cost() {
		return 7.99;
	}
}

