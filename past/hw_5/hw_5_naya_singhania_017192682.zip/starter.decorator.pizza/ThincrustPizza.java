public class ThincrustPizza extends Pizza {
  
	@Override
	public String toString () {
		return "Thin crust pizza, with tomato sauce";
	}
  
	@Override
	public double cost() {
		return 6.99;
	}
}

