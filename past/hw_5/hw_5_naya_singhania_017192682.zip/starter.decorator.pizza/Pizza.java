public abstract class Pizza {

	public abstract double cost();
}
