public abstract class ToppingDecorator extends Pizza {
	Pizza pizza;
}
