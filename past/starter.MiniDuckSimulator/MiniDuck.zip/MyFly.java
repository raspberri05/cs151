// xxx your codes
public class MyFly implements FlyBehavior {
	public void fly() {
		System.out.println("I fly in a new way taught by Naya Singhania");
	}
}