
// xxx your codes
public class MyQuack implements QuackBehavior {
	@Override
	public void quack() {
		System.out.println("I quack in a new way taught by Naya Singhania");
	}
}